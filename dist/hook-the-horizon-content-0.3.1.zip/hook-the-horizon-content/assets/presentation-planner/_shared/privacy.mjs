const LOCATION_KEYS = new Set([
  'lat', 'latitude', 'lng', 'lon', 'longitude', 'coordinates', 'coordinate',
  'exactlocation', 'exact_location', 'gps', 'geolocation', 'geojson',
  'waypoint', 'waypointid', 'waypoint_id', 'privatewatername', 'private_water_name',
  'accesspoint', 'access_point', 'parkingcoordinates', 'parking_coordinates',
  'homewaterbodyids', 'home_waterbody_ids'
]);

const PRIVACY_CLASSES = new Set(['public_safe', 'private', 'local_only', 'prohibited']);

function normalizedKey(value) {
  return String(value || '').replace(/[^a-z0-9_]/gi, '').toLowerCase();
}

function inspectString(value) {
  const text = String(value || '');
  const reasons = [];
  if (/\b-?\d{1,2}\.\d{4,}\s*[, ]\s*-?\d{1,3}\.\d{4,}\b/.test(text)) reasons.push('coordinate_pair');
  if (/https?:\/\/(?:www\.)?(?:google\.[^/]+\/maps|maps\.apple\.com|maps\.google\.com)/i.test(text)) reasons.push('map_url');
  if (/\b(?:lat(?:itude)?|lon(?:gitude)?|lng)\s*[:=]\s*-?\d+(?:\.\d+)?/i.test(text)) reasons.push('coordinate_label');
  if (/\b[23456789CFGHJMPQRVWX]{4,}\+[23456789CFGHJMPQRVWX]{2,}\b/i.test(text)) reasons.push('plus_code');
  return reasons;
}

export function inspectSensitiveLocation(value, path = '$', findings = []) {
  if (value === null || value === undefined) return findings;
  if (typeof value === 'string') {
    for (const reason of inspectString(value)) findings.push({ path, reason });
    return findings;
  }
  if (Array.isArray(value)) {
    value.forEach((item, index) => inspectSensitiveLocation(item, `${path}[${index}]`, findings));
    return findings;
  }
  if (typeof value === 'object') {
    for (const [key, nested] of Object.entries(value)) {
      const nestedPath = `${path}.${key}`;
      if (LOCATION_KEYS.has(normalizedKey(key))) findings.push({ path: nestedPath, reason: 'sensitive_location_key' });
      inspectSensitiveLocation(nested, nestedPath, findings);
    }
  }
  return findings;
}

function cloneRedacted(value, path, findings) {
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') {
    const reasons = inspectString(value);
    if (reasons.length) {
      reasons.forEach((reason) => findings.push({ path, reason }));
      return '[redacted-location]';
    }
    return value;
  }
  if (Array.isArray(value)) return value.map((item, index) => cloneRedacted(item, `${path}[${index}]`, findings));
  if (typeof value !== 'object') return value;

  const output = {};
  for (const [key, nested] of Object.entries(value)) {
    const nestedPath = `${path}.${key}`;
    if (LOCATION_KEYS.has(normalizedKey(key))) {
      findings.push({ path: nestedPath, reason: 'sensitive_location_key' });
      continue;
    }
    output[key] = cloneRedacted(nested, nestedPath, findings);
  }
  return output;
}

export function sanitizePublicPayload(value) {
  const findings = [];
  const sanitized = cloneRedacted(value, '$', findings);
  return { ok: findings.length === 0, sanitized, findings };
}

export function rejectSensitiveLocation(value) {
  const findings = inspectSensitiveLocation(value);
  return findings.length ? { ok: false, findings } : { ok: true, findings: [] };
}

export function classifyPrivacy(value) {
  const privacyClass = String(value || '').toLowerCase();
  if (!PRIVACY_CLASSES.has(privacyClass)) return { disposition: 'reject', reason: 'unknown_privacy_class' };
  if (privacyClass === 'prohibited') return { disposition: 'reject', reason: 'prohibited' };
  if (privacyClass === 'public_safe') return { disposition: 'public', reason: null };
  return { disposition: 'local', reason: null };
}
